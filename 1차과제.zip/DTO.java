package Day20;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

	public class DTO {
		private static int number = 0;
		private final static DateTimeFormatter DTF = DateTimeFormatter.ofPattern("yy/MM/dd hh:mm:ss");
		
		private String ono;
		private String title;
		private String writer;
		private int cnt;
		private int like;
		private int unholy;
		private String postDate;
		private String id ;
		private String pw ;
		
		public String getId() {
			return id;
		}

		public void setId(String id) {
			this.id = id;
		}

		public String getPw() {
			return pw;
		}

		public void setPw(String pw) {
			this.pw = pw;
		}

		public DTO() {
			this.ono = "O"+number++;
			this.postDate = DTF.format(LocalDateTime.now());
		}
		
		public DTO(String updateTitle, String updateWriter) {
			this.title = updateTitle;
			this.writer = updateWriter;
		}

		public String getBno() {
			return ono;
		}
		public int getLike() {
			return like;
		}

		public void setLike(int like) {
			this.like = like;
		}

		public int getUnholy() {
			return unholy;
		}

		public void setUnholy(int unholy) {
			this.unholy = unholy;
		}

		public String getTitle() {
			return title;
		}
		public void setTitle(String title) {
			this.title = title;
		}
		public String getWriter() {
			return writer;
		}
		public void setWriter(String writer) {
			this.writer = writer;
		}
		public int getCnt() {
			return cnt;
		}
		public void increaseCnt() {
			this.cnt++;
		}
		public String getPostDate() {
			return postDate;
		}
		
		public void print() {
			System.out.printf("%s\t%s\t%s\t%d\t%d\t%d\t%s\n",ono,title,writer,cnt,like,unholy,postDate);
		}

		@Override
		public String toString() {
			return "BoardDTO [ono=" + ono + ", title=" + title + ", writer=" + writer + ", cnt=" + cnt + ", like =" +like+ ", =unholy"+ unholy + ", postDate="
					+ postDate + "]";
		}

	
	}


