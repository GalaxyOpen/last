package Day20;

import java.util.ArrayList;
//import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Scanner;


public class Service {
	
    Service service = new Service();
    Service() {} //
	private static Repository br = Repository.getInstance();
	private List<DTO> list = new ArrayList<>();
	Scanner sc = new Scanner(System.in);
	
	String loginid = null;
	String loginpw = null;
	
	public static Repository getInstance() {
		return br;
	}
	

	public void announcement() {// 공지사항
		System.out.println("======================필독=======================");
		System.out.println("글번호\t공지\t\t작성자\t\t조회수\t좋아요\t싫어요\t업로드날짜");
		for (int i = 1; i <= 3; i++) {
			DTO DTO = new DTO();
			DTO.setWriter("관리자" + i);
			if (i == 1) {
				DTO.setTitle(i + ". 한줄의 제목이 내용입니다.");
			} else if (i == 2) {
				DTO.setTitle(i + ". 욕설을 사용하지 않습니다.");
			} else {
				DTO.setTitle(i + ". 바른말 사용을 부탁드립니다.");
			}

			DTO.print();
		}

	}

	public void save() {
		Scanner sc = new Scanner(System.in);
		DTO DTO = new DTO();

		System.out.print("제목> ");
		DTO.setTitle(sc.nextLine());
		System.out.print("작성자> ");
		DTO.setWriter(sc.next());
		sc.nextLine();

		boolean success = br.saving(DTO);
		if (success) {
			System.out.println("게시글 등록");
		} else {
			System.out.println("게시글 등록실패");
		}
		
	}

	public void findAll() { // 검색

		List<DTO> kS = br.findAll();
		// Collections.sort(kS, Collections.reverseOrder()); //내림차순
		// Collections.sort(kS); // 오름차순
		System.out.println("-----------------자유게시판-------------------------");
		System.out.println("글번호\t자유게시판\t\t작성자\t\t조회수\t좋아요\t싫어요\t업로드날짜");

		for (DTO d : kS) {
			d.print();
		}
	}
	public void findbyWriter() {
		Scanner sc = new Scanner(System.in);
		System.out.println("작성자 검색 >> ");
		String writer = sc.next();
		DTO DTO = br.findbyWriter(writer);
		if(DTO == null) {
			System.out.println("해당 작성자의 글을 찾을 수 없습니다.");
		}else {
			DTO.increaseCnt();
			System.out.println("=================================================");
			System.out.println("글번호\t공지\t\t작성자\t\t조회수\t좋아요\t싫어요\t업로드날짜");
			DTO.print();
			
		}
		
		
	}
	public void join() {
		System.out.println("아이디> ");
		String id = sc.next();
		System.out.println("비밀번호> ");
		String pw = sc.next();
		
		DTO DTO = new DTO(id, pw);
		if(br.saving(DTO)) {
			System.out.println("회원가입완료");
		}else {
		    System.out.println("회원가입실패");	
		}
				
	}
	public void login() {
		System.out.println("아이디> ");
		String id = sc.next();
		System.out.println("비밀번호> ");
		String pw = sc.next();
		
		if(br.login(id, pw)) {
			System.out.println("로그인 완료");
			loginid = id;
			loginpw = pw;
		}
		
		
	}

}
