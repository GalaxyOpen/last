package Day20;

import java.util.ArrayList;
import java.util.List;



public class Repository {
	private static Repository repository = new Repository();
	private List<DTO> list = new ArrayList<>();
	
	
	public boolean saving(DTO DTO) {
		boolean a = list.add(DTO);
		return a;
	}
	public List<DTO> findAll(){
		return list;
	}
	public DTO findbyWriter(String writer) {
		for(DTO d : list) {
			if(d.getWriter().equals(writer)) {
				return d;
			}
		}
		return null;
	}
	public static Repository getInstance() {
		
		return repository;
	}
	public boolean join(DTO DTO) {
		return list.add(DTO);
	}
	public boolean login(String id, String pw) {
		for(DTO d : list) {
			if(id.equals(d.getId()) && pw.equals(d.getPw())) {
				return true;
			}
		}return false;
	}


}
